# fasteryoutubesummary/__init__.py

from .get_video_summary import get_video_summary
